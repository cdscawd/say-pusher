You can use .cdproj file to quickly build and run samples in 
CodeDrive, the fastest ActionScript 3 IDE by iSpring.

To obtain CodeDrive, please follow the instruction here:
http://www.codedrive.com/installing.html

Then do the following to compile and run this project:

1) Open the .cdproj file in Visual Studio IDE or just double-click
   on it in Windows Explorer.
2) Press F5.

Note: if Visual Studio asks you to re-launch it with Administrator's
privileges, then you should either copy the whole Player SDK outside
the Program Files folder or agree to run Visual Studio as administrator.

More useful resources about CodeDrive AS3 IDE:
- Features: http://www.codedrive.com/features.html
- FAQ: http://www.codedrive.com/faq.html