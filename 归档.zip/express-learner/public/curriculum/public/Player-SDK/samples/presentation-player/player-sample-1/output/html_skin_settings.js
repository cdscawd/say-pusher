{
    "sidePanelSettings": {
        "sidePanelAtLeft": true
    }
}