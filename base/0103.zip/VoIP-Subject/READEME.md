
# 课程资源服务

## Start
```
  $ npm i
  $ npm run start
```

#About
 Subject server port is 8002 (/bin/www)
